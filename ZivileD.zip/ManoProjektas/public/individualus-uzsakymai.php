<?php
    $page = 'uzsakymai';
    include_once ('../app/views/header.php');
    include_once ('../app/views/footer.php');
?>
</body>
</html>