<?php
    $page = 'apie';
    include_once ('../app/views/header.php');
    include_once ('../app/views/footer.php');
?>
</body>
</html>